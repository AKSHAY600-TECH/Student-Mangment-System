C Application
======================
This is a simple C application. This application serves as a basic template for a console application using C.

What does this application do?
-------------------------------
This application prints "Hello, World!" to the console.

# How to run?
You can run the application in one of the following ways:

1. Open a terminal by going to 'View' -> 'Terminal'. Then run:
    > `gcc main.c`
    > `./a.out`

This will start the application.

Happy coding! 🙂